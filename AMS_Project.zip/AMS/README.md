# Ambulance Management System (AMS)

A menu-driven console application written entirely in **C** (SDMCET Software
Engineering project). It registers emergency requests, prioritises them,
allocates ambulances and drivers, tracks every trip and keeps all records in
binary files.

## Run in VS Code (Windows)

1. Install a C compiler (MinGW-w64 / MSYS2 `gcc`) and the **C/C++** extension.
2. `File > Open Folder...` and choose this `AMS` folder.
3. Press **Ctrl+Shift+B** to build (creates `ams.exe`).
4. In the VS Code terminal run: `.\ams.exe`  (or `Terminal > Run Task > Run AMS`).

Other ways: `mingw32-make` (Windows) or `make` (Linux/macOS), then run `ams`.
Run the program from the project folder so the `data/` folder is created there.

## First-run logins (created automatically)

| Role   | User ID      | Password    |
|--------|--------------|-------------|
| Admin  | `1`          | `admin123`  |
| Driver | `101`,`102`,`103` | `driver123` |
| Caller | register from the main menu (option 4) | your choice |

Change the passwords from each role's menu (**Change password**).
To reset everything, delete the `data/` folder.

## Login security

* Password is **hidden** while typing (`*` is shown).
* **3 attempts** per login, then login is **locked for 30 seconds**.
* The message says exactly what was wrong: **"Wrong User ID"** or
  **"Wrong Password"** (set `REVEAL_LOGIN_FAILURE_REASON` to `0` in
  `include/config.h` for one generic message instead - more secure).
* Passwords are stored as salted hashes, not plain text.
* All limits are in `include/config.h`.

## Project structure

```
AMS/
├── include/            header files (one per module + config/models)
├── src/
│   ├── main.c              main menu
│   ├── auth.c              login, registration, password change
│   ├── caller_module.c     submit / track / cancel requests
│   ├── admin_module.c      dispatcher: priority, allocation, monitoring, fleet
│   ├── driver_module.c     view assignments, update trip status
│   ├── request_mgmt.c      create / find / sort / print requests
│   ├── status_tracking.c   dispatch, status flow, cancellation
│   ├── search_filter.c     search & filter requests and ambulances
│   ├── fleet.c             ambulance and driver records
│   ├── storage.c           file handling (users/request/ambulance/driver .dat)
│   └── utils.c             safe input, hidden password, validation, time
├── .vscode/            build, run and debug configuration
├── Makefile
└── data/               created at run time (*.dat files)
```

## Rules implemented (from the synopsis and UML diagrams)

* Priority: 1-Critical, 2-Serious, 3-Normal (set automatically from the
  emergency type; Admin can change it).
* Status flow: Pending -> Dispatched -> En Route -> Transporting -> Completed.
  Cancel is allowed from Pending/Dispatched (caller or admin) and En Route (admin only).
* Allocating marks the ambulance **Busy**; completing or cancelling makes it **Available**.
* No free ambulance -> request stays Pending in the waiting queue and the admin
  sees an alert.
* Pending requests older than 2 / 5 / 10 minutes (Critical / Serious / Normal)
  are flagged **ESCALATE** in *Monitor delayed requests*.
* Requests are sorted by priority, then time. Duplicate active requests for the
  same patient are blocked. Contact numbers must be 10 digits.
