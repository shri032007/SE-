/*
 * caller_module.h - Caller Module: submit, track and cancel requests.
 */
#ifndef AMS_CALLER_MODULE_H
#define AMS_CALLER_MODULE_H

#include "models.h"

void caller_menu(const User *user);

#endif /* AMS_CALLER_MODULE_H */
