/*
 * config.h - Central configuration for the Ambulance Management System.
 * Change values here; no other file needs to be touched.
 */
#ifndef AMS_CONFIG_H
#define AMS_CONFIG_H

#define APP_NAME     "AMBULANCE MANAGEMENT SYSTEM"
#define APP_VERSION  "1.0.0"

/* ---------- File storage (File Handling Layer) ---------- */
#define DATA_DIR        "data"
#define USERS_FILE      DATA_DIR "/users.dat"
#define REQUEST_FILE    DATA_DIR "/request.dat"
#define AMBULANCE_FILE  DATA_DIR "/ambulance.dat"
#define DRIVER_FILE     DATA_DIR "/driver.dat"

/* ---------- Field sizes (same as the synopsis structures) ---------- */
#define NAME_LEN        30
#define PASSWORD_LEN    20
#define CONTACT_LEN     15
#define LOCATION_LEN    50
#define EMERGENCY_LEN   20
#define TIME_LEN        20      /* "YYYY-MM-DD HH:MM:SS" + '\0' */
#define VEHICLE_LEN     15
#define AMB_TYPE_LEN    10
#define AREA_LEN        20

/* ---------- Login security ---------- */
#define MAX_LOGIN_ATTEMPTS           3    /* wrong tries before lock-out      */
#define LOCKOUT_SECONDS              30   /* how long login stays locked      */
#define REVEAL_LOGIN_FAILURE_REASON  1    /* 1 = say "User ID wrong" or
                                             "Password wrong" separately;
                                             0 = one generic message          */
#define MIN_PASSWORD_LEN             6
#define PASSWORD_INPUT_MAX           31   /* max characters typed             */

/* ---------- Escalation: minutes a Pending request may wait ---------- */
#define ESCALATE_CRITICAL_MIN   2
#define ESCALATE_SERIOUS_MIN    5
#define ESCALATE_NORMAL_MIN     10

/* ---------- ID generation ---------- */
#define ADMIN_USER_ID       1
#define FIRST_USER_ID       100
#define FIRST_REQUEST_ID    1001
#define FIRST_AMBULANCE_ID  1

#endif /* AMS_CONFIG_H */
