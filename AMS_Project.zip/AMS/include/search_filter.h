/*
 * search_filter.h - Search and Filtering module (requests and ambulances).
 */
#ifndef AMS_SEARCH_FILTER_H
#define AMS_SEARCH_FILTER_H

/* callerId != 0 limits the search to that caller's own requests. */
void search_requests_menu(int callerId);
void search_ambulances_menu(void);

#endif /* AMS_SEARCH_FILTER_H */
