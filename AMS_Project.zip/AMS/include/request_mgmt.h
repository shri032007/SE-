/*
 * request_mgmt.h - Request Management: create, store, find, sort and print
 * emergency requests.
 */
#ifndef AMS_REQUEST_MGMT_H
#define AMS_REQUEST_MGMT_H

#include <stddef.h>
#include "models.h"

typedef struct {
    const char *name;
    int priority;                   /* initial priority for this emergency type */
} EmergencyType;

typedef struct {
    int total, pending, pendingCritical, dispatched, enRoute,
        transporting, completed, cancelled, delayed;
} RequestStats;

enum {
    RM_OK = 0,
    RM_ERR_NO_CALLER,
    RM_ERR_DUPLICATE,
    RM_ERR_IO,
    RM_ERR_NOT_FOUND,
    RM_ERR_CLOSED
};

const EmergencyType *request_emergency_types(int *count);
const char *priority_name(int priority);
const char *request_status_name(int status);
int  request_is_active(int status);          /* Pending .. Transporting */

/* On RM_ERR_DUPLICATE, *out holds the already-active request. */
int  request_create(int callerId, const char *patient, const char *contact,
                    const char *location, const char *emergencyType,
                    int priority, Request *out);
int  request_find(int requestId, Request *out);          /* 1 = found */
int  request_update(const Request *r);                   /* 0 = ok */
int  request_set_priority(int requestId, int priority);  /* RM_xxx */

void request_sort_by_priority(Request *arr, size_t n);   /* priority, then time */
int  request_wait_limit_minutes(int priority);
double request_wait_minutes(const Request *r);
int  request_get_stats(RequestStats *s);

void request_print_table(const Request *arr, size_t n);
void request_print_details(const Request *r);

#endif /* AMS_REQUEST_MGMT_H */
