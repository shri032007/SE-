/*
 * utils.h - Console UI helpers, safe input, validation, time and string tools.
 */
#ifndef AMS_UTILS_H
#define AMS_UTILS_H

#include <stddef.h>

/* ---- Console UI ---- */
void ui_clear(void);
void ui_header(const char *title);
void ui_line(void);
void ui_pause(void);

/* ---- Safe input (all of them exit cleanly if input is closed) ---- */
void input_line(const char *prompt, char *buf, size_t size);
void input_required(const char *prompt, char *buf, size_t size);
int  input_int(const char *prompt, int min, int max);
int  input_yes_no(const char *prompt);                 /* 1 = yes, 0 = no */
void input_name(const char *prompt, char *buf, size_t size);
void input_contact(const char *prompt, char *buf, size_t size);
void input_password(const char *prompt, char *buf, size_t size); /* hidden, shows '*' */

/* ---- Validation ---- */
int  validate_name(const char *s);
int  validate_contact(const char *s);                  /* exactly 10 digits */
int  validate_vehicle_no(const char *s);

/* ---- Strings ---- */
void str_trim(char *s);
void util_copy(char *dst, size_t size, const char *src);
void util_to_upper(char *s);
int  util_iequals(const char *a, const char *b);
int  util_icontains(const char *hay, const char *needle);
void util_wipe(void *p, size_t n);

/* ---- Time ---- */
void   time_now_str(char *buf, size_t size);           /* "YYYY-MM-DD HH:MM:SS" */
double minutes_since(const char *timestamp);

/* ---- File system ---- */
int  fs_ensure_dir(const char *path);

#endif /* AMS_UTILS_H */
