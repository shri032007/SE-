/*
 * fleet.h - Ambulance and driver records (fleet management).
 */
#ifndef AMS_FLEET_H
#define AMS_FLEET_H

#include <stddef.h>
#include "models.h"

enum {
    FLEET_OK = 0,
    FLEET_ERR_IO,
    FLEET_ERR_DUPLICATE,
    FLEET_ERR_BAD_DRIVER,
    FLEET_ERR_DRIVER_BUSY,
    FLEET_ERR_BAD_AMB,
    FLEET_ERR_AMB_TAKEN
};

const char *fleet_message(int code);
const char *fleet_status_name(int status);

int fleet_find_ambulance(int ambulanceId, Ambulance *out);            /* 1 = found */
int fleet_find_ambulance_by_driver(int driverId, Ambulance *out);     /* 1 = found */
int fleet_find_driver(int driverId, Driver *out);                     /* 1 = found */
int fleet_update_ambulance(const Ambulance *a);                       /* 0 = ok */
int fleet_update_driver(const Driver *d);                             /* 0 = ok */

int fleet_add_ambulance(const char *vehicleNo, const char *type, const char *area,
                        int driverId, Ambulance *out);
int fleet_add_driver(const char *name, const char *contact, const char *plainPassword,
                     int ambulanceId, Driver *out);

/* The returned arrays are malloc'd; caller must free(). */
int fleet_get_available(Ambulance **out, size_t *n);
int fleet_get_unassigned_drivers(Driver **out, size_t *n);
int fleet_get_unassigned_ambulances(Ambulance **out, size_t *n);

/* Best available ambulance (with a driver) - prefers the caller's area. */
int fleet_pick_ambulance(const char *location, Ambulance *out);       /* 1 = found */

void fleet_count(int *available, int *total);

void fleet_print_ambulances(const Ambulance *arr, size_t n);
void fleet_print_drivers(const Driver *arr, size_t n);

#endif /* AMS_FLEET_H */
