/*
 * driver_module.h - Driver Module: view assignments and update trip status.
 */
#ifndef AMS_DRIVER_MODULE_H
#define AMS_DRIVER_MODULE_H

#include "models.h"

void driver_menu(const User *user);

#endif /* AMS_DRIVER_MODULE_H */
