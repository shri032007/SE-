/*
 * admin_module.h - Admin (Dispatcher) Module.
 */
#ifndef AMS_ADMIN_MODULE_H
#define AMS_ADMIN_MODULE_H

#include "models.h"

void admin_menu(const User *user);

#endif /* AMS_ADMIN_MODULE_H */
