/*
 * models.h - Core data structures (see class diagram / synopsis section 7.4).
 */
#ifndef AMS_MODELS_H
#define AMS_MODELS_H

#include "config.h"

/* User roles */
typedef enum { ROLE_CALLER = 1, ROLE_ADMIN = 2, ROLE_DRIVER = 3 } Role;

/* Request priority */
enum { PRIORITY_CRITICAL = 1, PRIORITY_SERIOUS = 2, PRIORITY_NORMAL = 3 };

/* Request status flow (state transition diagram) */
enum {
    REQ_PENDING = 1,
    REQ_DISPATCHED,
    REQ_EN_ROUTE,
    REQ_TRANSPORTING,
    REQ_COMPLETED,
    REQ_CANCELLED
};

/* Ambulance status */
enum { AMB_BUSY = 0, AMB_AVAILABLE = 1 };

typedef struct User {
    int  userId;
    char name[NAME_LEN];
    char password[PASSWORD_LEN];   /* stores a hash, never the plain text */
    int  role;                     /* 1-Caller, 2-Admin, 3-Driver */
} User;

typedef struct Request {
    int  requestId;
    int  callerId;
    char patientName[NAME_LEN];
    char contact[CONTACT_LEN];
    char location[LOCATION_LEN];
    char emergencyType[EMERGENCY_LEN];
    int  priority;                 /* 1-Critical, 2-Serious, 3-Normal */
    int  status;                   /* Pending .. Cancelled */
    int  ambulanceId;              /* 0 = not allocated yet */
    char requestTime[TIME_LEN];
} Request;

typedef struct Ambulance {
    int  ambulanceId;
    char vehicleNo[VEHICLE_LEN];
    char type[AMB_TYPE_LEN];       /* BLS / ALS */
    char area[AREA_LEN];
    int  driverId;                 /* 0 = no driver */
    int  status;                   /* 0-Busy, 1-Available */
} Ambulance;

typedef struct Driver {
    int  driverId;                 /* same number as the driver's userId */
    char name[NAME_LEN];
    char contact[CONTACT_LEN];
    int  ambulanceId;              /* 0 = no ambulance */
} Driver;

#endif /* AMS_MODELS_H */
