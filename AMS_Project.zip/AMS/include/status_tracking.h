/*
 * status_tracking.h - Status Tracking: dispatch, status flow, cancellation.
 *
 * Flow: Pending -> Dispatched -> En Route -> Transporting -> Completed
 *       (Cancelled is possible from Pending, Dispatched and En Route)
 */
#ifndef AMS_STATUS_TRACKING_H
#define AMS_STATUS_TRACKING_H

enum {
    ST_OK = 0,
    ST_NOT_FOUND,
    ST_BAD_STATE,
    ST_NOT_OWNER,
    ST_ADMIN_ONLY,
    ST_AMB_NOT_FOUND,
    ST_AMB_UNAVAILABLE,
    ST_NO_DRIVER,
    ST_IO_ERROR
};

const char *status_message(int code);

/* Admin: allocate an ambulance (+ its driver) to a Pending request. */
int status_dispatch(int requestId, int ambulanceId);

/*
 * Move a request to its next status.
 * restrictAmbulanceId != 0 -> only allowed if that ambulance serves the request
 * (used by the driver module). Pass 0 for Admin.
 */
int status_advance(int requestId, int restrictAmbulanceId);

/*
 * Cancel a request.
 * Admin: callerId is ignored.  Caller: only own request, only Pending/Dispatched.
 */
int status_cancel(int requestId, int isAdmin, int callerId);

/* Next status name for a request currently in 'status' ("" if none). */
const char *status_next_name(int status);

#endif /* AMS_STATUS_TRACKING_H */
