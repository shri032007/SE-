/*
 * auth.h - Account Management: login, registration, password handling.
 */
#ifndef AMS_AUTH_H
#define AMS_AUTH_H

#include "models.h"

const char *auth_role_name(int role);

/* Hashes a password (salted with the user ID). Output fits in PASSWORD_LEN. */
void auth_hash_password(int userId, const char *plain, char out[PASSWORD_LEN]);

int  auth_find_user(int userId, User *out);                 /* 1 = found */

/* Creates a user record and returns the new user ID, or -1 on error. */
int  auth_create_user(const char *name, const char *plain, int role);

/*
 * Interactive login for one role. Hidden password, limited attempts, and a
 * clear message telling whether the User ID or the Password was wrong.
 * Returns 1 on success (user copied to *out), 0 otherwise.
 */
int  auth_login(int role, User *out);

int  auth_register_caller(void);                            /* 1 = registered */
void auth_change_password(const User *user);

#endif /* AMS_AUTH_H */
