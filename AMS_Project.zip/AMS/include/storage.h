/*
 * storage.h - File Handling Layer (fopen / fread / fwrite / fclose).
 *
 * Each data file stores fixed-size binary records:
 *   users.dat, request.dat, ambulance.dat, driver.dat
 *
 * load_xxx() returns 0 on success; *out is a malloc'd array (caller must
 * free()) or NULL when the file has no records (count == 0).
 */
#ifndef AMS_STORAGE_H
#define AMS_STORAGE_H

#include <stddef.h>
#include "models.h"

/* Creates the data folder and files; adds default data on the very first run. */
int storage_init(void);

int load_users(User **out, size_t *count);
int save_users(const User *arr, size_t count);
int append_user(const User *rec);

int load_requests(Request **out, size_t *count);
int save_requests(const Request *arr, size_t count);
int append_request(const Request *rec);

int load_ambulances(Ambulance **out, size_t *count);
int save_ambulances(const Ambulance *arr, size_t count);
int append_ambulance(const Ambulance *rec);

int load_drivers(Driver **out, size_t *count);
int save_drivers(const Driver *arr, size_t count);
int append_driver(const Driver *rec);

#endif /* AMS_STORAGE_H */
