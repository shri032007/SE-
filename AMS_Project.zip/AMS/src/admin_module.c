/*
 * admin_module.c - Admin (Dispatcher) Module.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "admin_module.h"
#include "auth.h"
#include "config.h"
#include "fleet.h"
#include "request_mgmt.h"
#include "search_filter.h"
#include "status_tracking.h"
#include "storage.h"
#include "utils.h"

/* ====================================================================== */
/*  Helpers                                                               */
/* ====================================================================== */

static void show_dashboard(void)
{
    RequestStats s;
    int availAmb, totalAmb;

    request_get_stats(&s);
    fleet_count(&availAmb, &totalAmb);

    printf("  Requests : %d total | %d pending | %d dispatched | %d en route | %d transporting\n",
           s.total, s.pending, s.dispatched, s.enRoute, s.transporting);
    printf("             %d completed | %d cancelled\n", s.completed, s.cancelled);
    printf("  Fleet    : %d of %d ambulance(s) available\n", availAmb, totalAmb);
    if (s.pending > 0) {
        printf("  [!] ALERT: %d request(s) waiting for an ambulance (%d critical).\n",
               s.pending, s.pendingCritical);
    }
    if (s.delayed > 0) {
        printf("  [!!] ESCALATION: %d request(s) have waited longer than the limit!\n", s.delayed);
    }
    ui_line();
}

/* Loads requests matching 'mode': 0 = all, 1 = active, 2 = pending only. */
static int load_filtered(int mode, Request **out, size_t *count)
{
    Request *arr = NULL;
    size_t n = 0, i, k = 0;

    *out = NULL;
    *count = 0;
    if (load_requests(&arr, &n) != 0) return -1;
    for (i = 0; i < n; i++) {
        int keep = 1;
        if (mode == 1) keep = request_is_active(arr[i].status);
        if (mode == 2) keep = (arr[i].status == REQ_PENDING);
        if (keep) arr[k++] = arr[i];
    }
    if (k == 0) { free(arr); return 0; }
    request_sort_by_priority(arr, k);
    *out = arr;
    *count = k;
    return 0;
}

/* ====================================================================== */
/*  Request handling                                                      */
/* ====================================================================== */

static void view_requests(void)
{
    Request *arr = NULL;
    size_t n = 0;
    int choice;

    ui_header("VIEW REQUESTS (priority order)");
    puts("  1. Active requests (queue)");
    puts("  2. All requests (including history)");
    choice = input_int("\nEnter choice: ", 1, 2);
    puts("");
    if (load_filtered(choice == 1 ? 1 : 0, &arr, &n) != 0) {
        puts("Error: unable to read requests.");
        return;
    }
    request_print_table(arr, n);
    free(arr);
}

static void set_priority(void)
{
    Request *arr = NULL, r;
    size_t n = 0;
    int id, p, rc;

    ui_header("SET REQUEST PRIORITY");
    if (load_filtered(1, &arr, &n) != 0) { puts("Error: unable to read requests."); return; }
    request_print_table(arr, n);
    free(arr);
    if (n == 0) return;

    id = input_int("\nEnter Request ID (0 to go back): ", 0, 999999);
    if (id == 0) return;
    if (!request_find(id, &r)) { puts("Request ID not found."); return; }
    printf("Current priority: %s\n", priority_name(r.priority));
    puts("  1. Critical   2. Serious   3. Normal");
    p = input_int("New priority: ", 1, 3);

    rc = request_set_priority(id, p);
    if (rc == RM_OK)             printf("\nPriority of request %d set to %s.\n", id, priority_name(p));
    else if (rc == RM_ERR_CLOSED) puts("\nThis request is already closed; priority cannot change.");
    else                          puts("\nError: could not update the request.");
}

static void allocate_manual(void)
{
    Request *pend = NULL, r;
    Ambulance *avail = NULL;
    size_t np = 0, na = 0;
    int id, ambId, rc;

    ui_header("ALLOCATE AMBULANCE (manual)");
    if (load_filtered(2, &pend, &np) != 0) { puts("Error: unable to read requests."); return; }
    if (np == 0) { puts("  No pending requests."); free(pend); return; }
    request_print_table(pend, np);
    free(pend);

    id = input_int("\nEnter Pending Request ID (0 to go back): ", 0, 999999);
    if (id == 0) return;
    if (!request_find(id, &r))        { puts("Request ID not found."); return; }
    if (r.status != REQ_PENDING)      { puts("That request is not Pending."); return; }

    if (fleet_get_available(&avail, &na) != 0) { puts("Error: unable to read ambulances."); return; }
    if (na == 0) {
        puts("\nNo ambulance is available. The request stays Pending in the waiting queue.");
        return;
    }
    puts("\nAvailable ambulances:");
    fleet_print_ambulances(avail, na);
    free(avail);

    ambId = input_int("\nEnter Ambulance ID to allocate (0 to go back): ", 0, 999999);
    if (ambId == 0) return;
    rc = status_dispatch(id, ambId);
    if (rc == ST_OK) printf("\nRequest %d dispatched with ambulance %d.\n", id, ambId);
    else             printf("\nCannot allocate: %s\n", status_message(rc));
}

static void allocate_auto(void)
{
    Request *pend = NULL, r;
    Ambulance a;
    size_t np = 0;
    int rc;

    ui_header("AUTO-ALLOCATE NEXT REQUEST");
    if (load_filtered(2, &pend, &np) != 0) { puts("Error: unable to read requests."); return; }
    if (np == 0) { puts("  No pending requests."); free(pend); return; }
    r = pend[0];                        /* highest priority, oldest first */
    free(pend);

    puts("Next request in the priority queue:");
    request_print_details(&r);

    if (!fleet_pick_ambulance(r.location, &a)) {
        puts("No available ambulance with a driver. The request stays Pending in the waiting queue.");
        puts("[!] Admin alert: escalate or free an ambulance.");
        return;
    }
    printf("Suggested ambulance: %s (%s, %s)\n", a.vehicleNo, a.type, a.area);
    if (!input_yes_no("Dispatch it now? (y/n): ")) { puts("Cancelled."); return; }

    rc = status_dispatch(r.requestId, a.ambulanceId);
    if (rc == ST_OK) printf("\nRequest %d dispatched with ambulance %d.\n", r.requestId, a.ambulanceId);
    else             printf("\nCannot allocate: %s\n", status_message(rc));
}

static void update_status(void)
{
    Request *arr = NULL, r;
    size_t n = 0;
    int id, rc;

    ui_header("UPDATE REQUEST STATUS");
    if (load_filtered(1, &arr, &n) != 0) { puts("Error: unable to read requests."); return; }
    request_print_table(arr, n);
    free(arr);
    if (n == 0) return;

    id = input_int("\nEnter Request ID (0 to go back): ", 0, 999999);
    if (id == 0) return;
    if (!request_find(id, &r)) { puts("Request ID not found."); return; }
    if (r.status == REQ_PENDING) {
        puts("This request is Pending. Allocate an ambulance first (menu option 4 or 5).");
        return;
    }
    if (!request_is_active(r.status)) { puts("This request is already closed."); return; }

    printf("Update status:  %s  ->  %s\n", request_status_name(r.status), status_next_name(r.status));
    if (!input_yes_no("Confirm? (y/n): ")) { puts("Cancelled."); return; }
    rc = status_advance(id, 0);
    if (rc == ST_OK) puts("\nStatus updated.");
    else             printf("\nCannot update: %s\n", status_message(rc));
}

static void cancel_request(void)
{
    Request *arr = NULL, r;
    size_t n = 0;
    int id, rc;

    ui_header("CANCEL REQUEST");
    if (load_filtered(1, &arr, &n) != 0) { puts("Error: unable to read requests."); return; }
    request_print_table(arr, n);
    free(arr);
    if (n == 0) return;

    id = input_int("\nEnter Request ID to cancel (0 to go back): ", 0, 999999);
    if (id == 0) return;
    if (!request_find(id, &r)) { puts("Request ID not found."); return; }
    request_print_details(&r);
    if (!input_yes_no("Cancel this request? (y/n): ")) { puts("Aborted."); return; }
    rc = status_cancel(id, 1, 0);
    if (rc == ST_OK) puts("\nRequest cancelled. Its ambulance (if any) is Available again.");
    else             printf("\nCannot cancel: %s\n", status_message(rc));
}

static void monitor_delayed(void)
{
    Request *pend = NULL;
    size_t n = 0, i;
    int delayed = 0;

    ui_header("MONITOR DELAYED / UNATTENDED REQUESTS");
    if (load_filtered(2, &pend, &n) != 0) { puts("Error: unable to read requests."); return; }
    if (n == 0) { puts("  No unattended requests. All requests have an ambulance."); free(pend); return; }

    printf("%-5s %-14s %-9s %-10s %-8s %-12s\n",
           "ID", "Patient", "Priority", "Waiting", "Limit", "Action");
    ui_line();
    for (i = 0; i < n; i++) {
        double wait = request_wait_minutes(&pend[i]);
        int limit = request_wait_limit_minutes(pend[i].priority);
        int late = wait >= limit;
        if (late) delayed++;
        printf("%-5d %-14.14s %-9s %-4d min   %-3d min  %-12s\n",
               pend[i].requestId, pend[i].patientName, priority_name(pend[i].priority),
               (int)wait, limit, late ? "ESCALATE!" : "Within limit");
    }
    printf("\n  Unattended: %d   |   Delayed beyond limit: %d\n", (int)n, delayed);
    if (delayed > 0) puts("  [!] Escalate delayed requests: free an ambulance or allocate immediately.");
    free(pend);
}

/* ====================================================================== */
/*  Fleet management                                                      */
/* ====================================================================== */

static void view_ambulances(void)
{
    Ambulance *arr = NULL;
    size_t n = 0;
    ui_header("ALL AMBULANCES");
    if (load_ambulances(&arr, &n) != 0) { puts("Error: unable to read ambulances."); return; }
    fleet_print_ambulances(arr, n);
    free(arr);
}

static void view_drivers(void)
{
    Driver *arr = NULL;
    size_t n = 0;
    ui_header("ALL DRIVERS");
    if (load_drivers(&arr, &n) != 0) { puts("Error: unable to read drivers."); return; }
    fleet_print_drivers(arr, n);
    free(arr);
}

static void add_ambulance(void)
{
    char veh[VEHICLE_LEN], area[AREA_LEN];
    const char *type;
    Driver *free_drivers = NULL;
    size_t nd = 0;
    int driverId = 0, rc;
    Ambulance a;

    ui_header("ADD AMBULANCE");
    for (;;) {
        input_required("  Vehicle number (e.g. KA25AB1234): ", veh, sizeof veh);
        if (validate_vehicle_no(veh)) break;
        puts("  Vehicle number must be 6-14 letters/digits, no spaces.");
    }
    util_to_upper(veh);
    puts("  Ambulance type:  1. BLS (Basic)   2. ALS (Advanced)");
    type = input_int("  Select type: ", 1, 2) == 1 ? "BLS" : "ALS";
    input_required("  Operating area: ", area, sizeof area);

    if (fleet_get_unassigned_drivers(&free_drivers, &nd) == 0 && nd > 0) {
        puts("\n  Drivers without an ambulance:");
        fleet_print_drivers(free_drivers, nd);
        driverId = input_int("\n  Assign Driver ID (0 = none for now): ", 0, 999999);
    }
    free(free_drivers);

    rc = fleet_add_ambulance(veh, type, area, driverId, &a);
    if (rc == FLEET_OK) {
        printf("\nAmbulance added. Ambulance ID: %d (%s)\n", a.ambulanceId, a.vehicleNo);
        if (driverId == 0) puts("  Note: it cannot be dispatched until a driver is assigned.");
    } else {
        printf("\nCould not add ambulance: %s\n", fleet_message(rc));
    }
}

static void add_driver(void)
{
    char name[NAME_LEN], contact[CONTACT_LEN];
    char pw[PASSWORD_INPUT_MAX + 1], pw2[PASSWORD_INPUT_MAX + 1];
    Ambulance *free_amb = NULL;
    size_t na = 0;
    int ambId = 0, rc;
    Driver d;

    ui_header("ADD DRIVER");
    input_name("  Driver name        : ", name, sizeof name);
    input_contact("  Contact (10 digits): ", contact, sizeof contact);
    for (;;) {
        input_password("  Initial password   : ", pw, sizeof pw);
        if (strlen(pw) < MIN_PASSWORD_LEN) {
            printf("  Password must be at least %d characters.\n", MIN_PASSWORD_LEN);
            continue;
        }
        input_password("  Confirm password   : ", pw2, sizeof pw2);
        if (strcmp(pw, pw2) != 0) { puts("  Passwords do not match."); continue; }
        break;
    }
    util_wipe(pw2, sizeof pw2);

    if (fleet_get_unassigned_ambulances(&free_amb, &na) == 0 && na > 0) {
        puts("\n  Ambulances without a driver:");
        fleet_print_ambulances(free_amb, na);
        ambId = input_int("\n  Assign Ambulance ID (0 = none for now): ", 0, 999999);
    }
    free(free_amb);

    rc = fleet_add_driver(name, contact, pw, ambId, &d);
    util_wipe(pw, sizeof pw);
    if (rc == FLEET_OK) {
        printf("\nDriver registered. Login User ID: %d\n", d.driverId);
    } else {
        printf("\nCould not add driver: %s\n", fleet_message(rc));
    }
}

static void fleet_menu(void)
{
    for (;;) {
        int choice;
        ui_header("FLEET MANAGEMENT");
        puts("  1. View all ambulances");
        puts("  2. Search / filter ambulances");
        puts("  3. Add ambulance");
        puts("  4. View all drivers");
        puts("  5. Add driver");
        puts("  0. Back");
        choice = input_int("\nEnter choice: ", 0, 5);
        switch (choice) {
            case 1: view_ambulances();        ui_pause(); break;
            case 2: search_ambulances_menu();             break;
            case 3: add_ambulance();          ui_pause(); break;
            case 4: view_drivers();           ui_pause(); break;
            case 5: add_driver();             ui_pause(); break;
            case 0: return;
            default: break;
        }
    }
}

/* ====================================================================== */
/*  Admin main menu                                                       */
/* ====================================================================== */

void admin_menu(const User *user)
{
    for (;;) {
        int choice;
        ui_header("ADMIN (DISPATCHER) MENU");
        printf("  Logged in as: %s (ID %d)\n", user->name, user->userId);
        ui_line();
        show_dashboard();
        puts("  1. View requests (priority queue)");
        puts("  2. Search / filter requests");
        puts("  3. Set request priority");
        puts("  4. Allocate ambulance (manual)");
        puts("  5. Auto-allocate next request");
        puts("  6. Update request status");
        puts("  7. Cancel request");
        puts("  8. Monitor delayed / unattended requests");
        puts("  9. Fleet management (ambulances & drivers)");
        puts(" 10. Change password");
        puts("  0. Logout");
        choice = input_int("\nEnter choice: ", 0, 10);

        switch (choice) {
            case 1:  view_requests();               ui_pause(); break;
            case 2:  search_requests_menu(0);                   break;
            case 3:  set_priority();                ui_pause(); break;
            case 4:  allocate_manual();             ui_pause(); break;
            case 5:  allocate_auto();               ui_pause(); break;
            case 6:  update_status();               ui_pause(); break;
            case 7:  cancel_request();              ui_pause(); break;
            case 8:  monitor_delayed();             ui_pause(); break;
            case 9:  fleet_menu();                              break;
            case 10: auth_change_password(user);    ui_pause(); break;
            case 0:  puts("\nLogged out."); return;
            default: break;
        }
    }
}
