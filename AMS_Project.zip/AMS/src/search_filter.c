/*
 * search_filter.c - Search and Filtering module.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "fleet.h"
#include "request_mgmt.h"
#include "search_filter.h"
#include "storage.h"
#include "utils.h"

enum { BY_ID = 1, BY_PRIORITY, BY_STATUS, BY_LOCATION, BY_PATIENT };

typedef struct {
    int  mode;
    int  value;
    char text[LOCATION_LEN];
} ReqFilter;

static int req_matches(const Request *r, const ReqFilter *f)
{
    switch (f->mode) {
        case BY_ID:       return r->requestId == f->value;
        case BY_PRIORITY: return r->priority == f->value;
        case BY_STATUS:   return r->status == f->value;
        case BY_LOCATION: return util_icontains(r->location, f->text);
        case BY_PATIENT:  return util_icontains(r->patientName, f->text);
        default:          return 0;
    }
}

void search_requests_menu(int callerId)
{
    for (;;) {
        ReqFilter f;
        Request *arr = NULL;
        size_t n = 0, i, k = 0;
        int choice;

        ui_header(callerId ? "SEARCH / FILTER MY REQUESTS" : "SEARCH / FILTER REQUESTS");
        puts("  1. By Request ID");
        puts("  2. By Priority");
        puts("  3. By Status");
        puts("  4. By Location / Area keyword");
        puts("  5. By Patient name keyword");
        puts("  0. Back");
        choice = input_int("\nEnter choice: ", 0, 5);
        if (choice == 0) return;

        memset(&f, 0, sizeof f);
        f.mode = choice;
        switch (choice) {
            case BY_ID:
                f.value = input_int("Request ID: ", 1, 999999);
                break;
            case BY_PRIORITY:
                puts("  1-Critical  2-Serious  3-Normal");
                f.value = input_int("Priority: ", 1, 3);
                break;
            case BY_STATUS:
                puts("  1-Pending  2-Dispatched  3-En Route  4-Transporting  5-Completed  6-Cancelled");
                f.value = input_int("Status: ", 1, 6);
                break;
            default:
                input_required("Keyword: ", f.text, sizeof f.text);
                break;
        }

        if (load_requests(&arr, &n) != 0) {
            puts("Error: unable to read requests.");
            ui_pause();
            continue;
        }
        for (i = 0; i < n; i++) {
            if (callerId != 0 && arr[i].callerId != callerId) continue;
            if (req_matches(&arr[i], &f)) arr[k++] = arr[i];
        }
        request_sort_by_priority(arr, k);
        puts("");
        request_print_table(arr, k);
        free(arr);
        ui_pause();
    }
}

/* ---------------- ambulances ---------------- */

void search_ambulances_menu(void)
{
    for (;;) {
        Ambulance *arr = NULL;
        size_t n = 0, i, k = 0;
        int choice, value = 0;
        char text[AREA_LEN] = "";

        ui_header("SEARCH / FILTER AMBULANCES");
        puts("  1. By Ambulance ID");
        puts("  2. By Area keyword");
        puts("  3. By Status (Available / Busy)");
        puts("  4. By Type (BLS / ALS)");
        puts("  0. Back");
        choice = input_int("\nEnter choice: ", 0, 4);
        if (choice == 0) return;

        if (choice == 1) {
            value = input_int("Ambulance ID: ", 1, 999999);
        } else if (choice == 2) {
            input_required("Area keyword: ", text, sizeof text);
        } else if (choice == 3) {
            puts("  1-Available  2-Busy");
            value = input_int("Status: ", 1, 2);
        } else {
            puts("  1-BLS  2-ALS");
            value = input_int("Type: ", 1, 2);
        }

        if (load_ambulances(&arr, &n) != 0) {
            puts("Error: unable to read ambulances.");
            ui_pause();
            continue;
        }
        for (i = 0; i < n; i++) {
            int ok = 0;
            switch (choice) {
                case 1: ok = arr[i].ambulanceId == value; break;
                case 2: ok = util_icontains(arr[i].area, text); break;
                case 3: ok = (value == 1) ? arr[i].status == AMB_AVAILABLE
                                          : arr[i].status == AMB_BUSY; break;
                default: ok = util_iequals(arr[i].type, value == 1 ? "BLS" : "ALS"); break;
            }
            if (ok) arr[k++] = arr[i];
        }
        puts("");
        fleet_print_ambulances(arr, k);
        free(arr);
        ui_pause();
    }
}
