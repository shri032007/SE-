/*
 * driver_module.c - Driver Module.
 */
#include <stdio.h>
#include <stdlib.h>

#include "auth.h"
#include "driver_module.h"
#include "fleet.h"
#include "request_mgmt.h"
#include "status_tracking.h"
#include "storage.h"
#include "utils.h"

/* Collects this ambulance's requests. activeOnly=1 -> only open trips. */
static int load_assigned(int ambulanceId, int activeOnly, Request **out, size_t *count)
{
    Request *arr = NULL;
    size_t n = 0, i, k = 0;

    *out = NULL;
    *count = 0;
    if (load_requests(&arr, &n) != 0) return -1;
    for (i = 0; i < n; i++) {
        int active = request_is_active(arr[i].status);
        if (arr[i].ambulanceId != ambulanceId) continue;
        if (activeOnly != active) continue;
        arr[k++] = arr[i];
    }
    if (k == 0) { free(arr); return 0; }
    request_sort_by_priority(arr, k);
    *out = arr;
    *count = k;
    return 0;
}

static void show_assignments(const Ambulance *amb)
{
    Request *arr = NULL;
    size_t n = 0, i;

    ui_header("MY ASSIGNED REQUESTS");
    if (load_assigned(amb->ambulanceId, 1, &arr, &n) != 0) {
        puts("Error: unable to read requests.");
        return;
    }
    if (n == 0) {
        puts("  No active assignments right now.");
    } else {
        for (i = 0; i < n; i++) request_print_details(&arr[i]);
    }
    free(arr);
}

static void update_trip_status(const Ambulance *amb)
{
    Request *arr = NULL;
    size_t n = 0, i;
    int id = 0, rc;
    const Request *chosen = NULL;

    ui_header("UPDATE TRIP STATUS");
    if (load_assigned(amb->ambulanceId, 1, &arr, &n) != 0) {
        puts("Error: unable to read requests.");
        return;
    }
    if (n == 0) {
        puts("  No active assignments to update.");
        free(arr);
        return;
    }
    if (n == 1) {
        chosen = &arr[0];
    } else {
        request_print_table(arr, n);
        id = input_int("\nEnter Request ID (0 to go back): ", 0, 999999);
        if (id == 0) { free(arr); return; }
        for (i = 0; i < n; i++) if (arr[i].requestId == id) chosen = &arr[i];
        if (chosen == NULL) {
            puts("  That request is not assigned to your ambulance.");
            free(arr);
            return;
        }
    }

    request_print_details(chosen);
    printf("  Update status:  %s  ->  %s\n\n",
           request_status_name(chosen->status), status_next_name(chosen->status));
    if (input_yes_no("Confirm update? (y/n): ")) {
        rc = status_advance(chosen->requestId, amb->ambulanceId);
        if (rc == ST_OK) {
            puts("\nStatus updated.");
            if (chosen->status + 1 == REQ_COMPLETED) {
                puts("  Trip completed. Your ambulance is now Available.");
            }
        } else {
            printf("\nCannot update: %s\n", status_message(rc));
        }
    } else {
        puts("Update cancelled.");
    }
    free(arr);
}

static void show_history(const Ambulance *amb)
{
    Request *arr = NULL;
    size_t n = 0;

    ui_header("MY TRIP HISTORY");
    if (load_assigned(amb->ambulanceId, 0, &arr, &n) != 0) {
        puts("Error: unable to read requests.");
        return;
    }
    request_print_table(arr, n);
    free(arr);
}

void driver_menu(const User *user)
{
    for (;;) {
        Ambulance amb;
        int hasAmb = fleet_find_ambulance_by_driver(user->userId, &amb);
        int choice;

        ui_header("DRIVER MENU");
        printf("  Logged in as: %s (ID %d)\n", user->name, user->userId);
        if (hasAmb) {
            printf("  Ambulance   : %s (%s, %s) - %s\n", amb.vehicleNo, amb.type,
                   amb.area, fleet_status_name(amb.status));
        } else {
            puts("  Ambulance   : none assigned - please contact the Admin.");
        }
        puts("");
        puts("  1. View my assigned requests");
        puts("  2. Update trip status");
        puts("  3. View my trip history");
        puts("  4. Change password");
        puts("  0. Logout");
        choice = input_int("\nEnter choice: ", 0, 4);

        if (choice == 0) { puts("\nLogged out."); return; }
        if (choice == 4) { auth_change_password(user); ui_pause(); continue; }
        if (!hasAmb) {
            puts("\nNo ambulance is assigned to you yet.");
            ui_pause();
            continue;
        }
        switch (choice) {
            case 1: show_assignments(&amb);  break;
            case 2: update_trip_status(&amb); break;
            case 3: show_history(&amb);       break;
            default: break;
        }
        ui_pause();
    }
}
