/*
 * fleet.c - Ambulance and driver management.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "auth.h"
#include "fleet.h"
#include "storage.h"
#include "utils.h"

const char *fleet_message(int code)
{
    switch (code) {
        case FLEET_OK:             return "Done.";
        case FLEET_ERR_IO:         return "File error - could not read or save data.";
        case FLEET_ERR_DUPLICATE:  return "An ambulance with this vehicle number already exists.";
        case FLEET_ERR_BAD_DRIVER: return "Driver ID not found.";
        case FLEET_ERR_DRIVER_BUSY:return "That driver already has an ambulance.";
        case FLEET_ERR_BAD_AMB:    return "Ambulance ID not found.";
        case FLEET_ERR_AMB_TAKEN:  return "That ambulance already has a driver.";
        default:                   return "Unknown error.";
    }
}

const char *fleet_status_name(int status)
{
    return status == AMB_AVAILABLE ? "Available" : "Busy";
}

/* ---------------- lookups ---------------- */

int fleet_find_ambulance(int ambulanceId, Ambulance *out)
{
    Ambulance *arr = NULL;
    size_t n = 0, i;
    int found = 0;
    if (load_ambulances(&arr, &n) != 0) return 0;
    for (i = 0; i < n; i++) {
        if (arr[i].ambulanceId == ambulanceId) {
            if (out != NULL) *out = arr[i];
            found = 1;
            break;
        }
    }
    free(arr);
    return found;
}

int fleet_find_ambulance_by_driver(int driverId, Ambulance *out)
{
    Ambulance *arr = NULL;
    size_t n = 0, i;
    int found = 0;
    if (load_ambulances(&arr, &n) != 0) return 0;
    for (i = 0; i < n; i++) {
        if (arr[i].driverId == driverId) {
            if (out != NULL) *out = arr[i];
            found = 1;
            break;
        }
    }
    free(arr);
    return found;
}

int fleet_find_driver(int driverId, Driver *out)
{
    Driver *arr = NULL;
    size_t n = 0, i;
    int found = 0;
    if (load_drivers(&arr, &n) != 0) return 0;
    for (i = 0; i < n; i++) {
        if (arr[i].driverId == driverId) {
            if (out != NULL) *out = arr[i];
            found = 1;
            break;
        }
    }
    free(arr);
    return found;
}

/* ---------------- updates ---------------- */

int fleet_update_ambulance(const Ambulance *a)
{
    Ambulance *arr = NULL;
    size_t n = 0, i;
    int rc = -1;
    if (load_ambulances(&arr, &n) != 0) return -1;
    for (i = 0; i < n; i++) {
        if (arr[i].ambulanceId == a->ambulanceId) {
            arr[i] = *a;
            rc = save_ambulances(arr, n);
            break;
        }
    }
    free(arr);
    return rc;
}

int fleet_update_driver(const Driver *d)
{
    Driver *arr = NULL;
    size_t n = 0, i;
    int rc = -1;
    if (load_drivers(&arr, &n) != 0) return -1;
    for (i = 0; i < n; i++) {
        if (arr[i].driverId == d->driverId) {
            arr[i] = *d;
            rc = save_drivers(arr, n);
            break;
        }
    }
    free(arr);
    return rc;
}

/* ---------------- add ---------------- */

int fleet_add_ambulance(const char *vehicleNo, const char *type, const char *area,
                        int driverId, Ambulance *out)
{
    Ambulance *arr = NULL, a;
    Driver d;
    size_t n = 0, i;
    int maxId = FIRST_AMBULANCE_ID - 1;

    if (load_ambulances(&arr, &n) != 0) return FLEET_ERR_IO;
    for (i = 0; i < n; i++) {
        if (util_iequals(arr[i].vehicleNo, vehicleNo)) { free(arr); return FLEET_ERR_DUPLICATE; }
        if (arr[i].ambulanceId > maxId) maxId = arr[i].ambulanceId;
    }
    free(arr);

    memset(&d, 0, sizeof d);
    if (driverId != 0) {
        if (!fleet_find_driver(driverId, &d)) return FLEET_ERR_BAD_DRIVER;
        if (d.ambulanceId != 0)               return FLEET_ERR_DRIVER_BUSY;
    }

    memset(&a, 0, sizeof a);
    a.ambulanceId = maxId + 1;
    util_copy(a.vehicleNo, sizeof a.vehicleNo, vehicleNo);
    util_copy(a.type, sizeof a.type, type);
    util_copy(a.area, sizeof a.area, area);
    a.driverId = driverId;
    a.status = AMB_AVAILABLE;

    if (append_ambulance(&a) != 0) return FLEET_ERR_IO;
    if (driverId != 0) {
        d.ambulanceId = a.ambulanceId;
        if (fleet_update_driver(&d) != 0) return FLEET_ERR_IO;
    }
    if (out != NULL) *out = a;
    return FLEET_OK;
}

int fleet_add_driver(const char *name, const char *contact, const char *plainPassword,
                     int ambulanceId, Driver *out)
{
    Driver d;
    Ambulance a;
    int id;

    memset(&a, 0, sizeof a);
    if (ambulanceId != 0) {
        if (!fleet_find_ambulance(ambulanceId, &a)) return FLEET_ERR_BAD_AMB;
        if (a.driverId != 0)                        return FLEET_ERR_AMB_TAKEN;
    }

    id = auth_create_user(name, plainPassword, ROLE_DRIVER);
    if (id < 0) return FLEET_ERR_IO;

    memset(&d, 0, sizeof d);
    d.driverId = id;
    util_copy(d.name, sizeof d.name, name);
    util_copy(d.contact, sizeof d.contact, contact);
    d.ambulanceId = ambulanceId;
    if (append_driver(&d) != 0) return FLEET_ERR_IO;

    if (ambulanceId != 0) {
        a.driverId = id;
        if (fleet_update_ambulance(&a) != 0) return FLEET_ERR_IO;
    }
    if (out != NULL) *out = d;
    return FLEET_OK;
}

/* ---------------- filtered lists ---------------- */

int fleet_get_available(Ambulance **out, size_t *n)
{
    Ambulance *all = NULL;
    size_t cnt = 0, i, k = 0;
    *out = NULL;
    *n = 0;
    if (load_ambulances(&all, &cnt) != 0) return -1;
    if (cnt == 0) return 0;
    for (i = 0; i < cnt; i++) {
        if (all[i].status == AMB_AVAILABLE) all[k++] = all[i];
    }
    if (k == 0) { free(all); return 0; }
    *out = all;
    *n = k;
    return 0;
}

int fleet_get_unassigned_drivers(Driver **out, size_t *n)
{
    Driver *all = NULL;
    size_t cnt = 0, i, k = 0;
    *out = NULL;
    *n = 0;
    if (load_drivers(&all, &cnt) != 0) return -1;
    if (cnt == 0) return 0;
    for (i = 0; i < cnt; i++) {
        if (all[i].ambulanceId == 0) all[k++] = all[i];
    }
    if (k == 0) { free(all); return 0; }
    *out = all;
    *n = k;
    return 0;
}

int fleet_get_unassigned_ambulances(Ambulance **out, size_t *n)
{
    Ambulance *all = NULL;
    size_t cnt = 0, i, k = 0;
    *out = NULL;
    *n = 0;
    if (load_ambulances(&all, &cnt) != 0) return -1;
    if (cnt == 0) return 0;
    for (i = 0; i < cnt; i++) {
        if (all[i].driverId == 0) all[k++] = all[i];
    }
    if (k == 0) { free(all); return 0; }
    *out = all;
    *n = k;
    return 0;
}

int fleet_pick_ambulance(const char *location, Ambulance *out)
{
    Ambulance *arr = NULL;
    size_t n = 0, i;
    int best = -1;

    if (load_ambulances(&arr, &n) != 0) return 0;
    for (i = 0; i < n; i++) {
        if (arr[i].status != AMB_AVAILABLE || arr[i].driverId == 0) continue;
        if (best < 0) best = (int)i;                       /* first usable one */
        if (util_icontains(location, arr[i].area)) {       /* same area wins   */
            best = (int)i;
            break;
        }
    }
    if (best >= 0 && out != NULL) *out = arr[best];
    free(arr);
    return best >= 0;
}

void fleet_count(int *available, int *total)
{
    Ambulance *arr = NULL;
    size_t n = 0, i;
    *available = 0;
    *total = 0;
    if (load_ambulances(&arr, &n) != 0) return;
    *total = (int)n;
    for (i = 0; i < n; i++) {
        if (arr[i].status == AMB_AVAILABLE) (*available)++;
    }
    free(arr);
}

/* ---------------- printing ---------------- */

void fleet_print_ambulances(const Ambulance *arr, size_t n)
{
    Driver *drivers = NULL;
    size_t dn = 0, i, j;

    if (n == 0) { puts("  (no ambulances to show)"); return; }
    if (load_drivers(&drivers, &dn) != 0) { drivers = NULL; dn = 0; }

    printf("%-4s %-14s %-5s %-16s %-22s %-9s\n",
           "ID", "Vehicle No", "Type", "Area", "Driver", "Status");
    ui_line();
    for (i = 0; i < n; i++) {
        char drv[40] = "-";
        for (j = 0; j < dn; j++) {
            if (drivers[j].driverId == arr[i].driverId) {
                snprintf(drv, sizeof drv, "%s (%d)", drivers[j].name, drivers[j].driverId);
                break;
            }
        }
        printf("%-4d %-14.14s %-5.5s %-16.16s %-22.22s %-9s\n",
               arr[i].ambulanceId, arr[i].vehicleNo, arr[i].type, arr[i].area,
               drv, fleet_status_name(arr[i].status));
    }
    free(drivers);
}

void fleet_print_drivers(const Driver *arr, size_t n)
{
    Ambulance *amb = NULL;
    size_t an = 0, i, j;

    if (n == 0) { puts("  (no drivers to show)"); return; }
    if (load_ambulances(&amb, &an) != 0) { amb = NULL; an = 0; }

    printf("%-5s %-24s %-12s %-14s\n", "ID", "Name", "Contact", "Ambulance");
    ui_line();
    for (i = 0; i < n; i++) {
        char veh[24] = "-";
        for (j = 0; j < an; j++) {
            if (amb[j].ambulanceId == arr[i].ambulanceId) {
                snprintf(veh, sizeof veh, "%s", amb[j].vehicleNo);
                break;
            }
        }
        printf("%-5d %-24.24s %-12s %-14s\n",
               arr[i].driverId, arr[i].name, arr[i].contact, veh);
    }
    free(amb);
}
