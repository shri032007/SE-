/*
 * status_tracking.c - Status Tracking module.
 */
#include <stdio.h>

#include "fleet.h"
#include "models.h"
#include "request_mgmt.h"
#include "status_tracking.h"

const char *status_message(int code)
{
    switch (code) {
        case ST_OK:              return "Done.";
        case ST_NOT_FOUND:       return "Request ID not found.";
        case ST_BAD_STATE:       return "This action is not allowed in the request's current status.";
        case ST_NOT_OWNER:       return "This request does not belong to you / your ambulance.";
        case ST_ADMIN_ONLY:      return "The ambulance is already on the way. Please contact the dispatcher to cancel.";
        case ST_AMB_NOT_FOUND:   return "Ambulance ID not found.";
        case ST_AMB_UNAVAILABLE: return "That ambulance is not available (it is Busy).";
        case ST_NO_DRIVER:       return "That ambulance has no driver assigned.";
        case ST_IO_ERROR:        return "File error - could not save changes.";
        default:                 return "Unknown error.";
    }
}

const char *status_next_name(int status)
{
    if (status >= REQ_DISPATCHED && status <= REQ_TRANSPORTING) {
        return request_status_name(status + 1);
    }
    return "";
}

/* Marks the ambulance of a finished/cancelled request as Available again. */
static int release_ambulance(int ambulanceId)
{
    Ambulance a;
    if (ambulanceId == 0) return 0;
    if (!fleet_find_ambulance(ambulanceId, &a)) return 0;
    a.status = AMB_AVAILABLE;
    return fleet_update_ambulance(&a);
}

int status_dispatch(int requestId, int ambulanceId)
{
    Request r;
    Ambulance a;

    if (!request_find(requestId, &r))             return ST_NOT_FOUND;
    if (r.status != REQ_PENDING)                  return ST_BAD_STATE;
    if (!fleet_find_ambulance(ambulanceId, &a))   return ST_AMB_NOT_FOUND;
    if (a.status != AMB_AVAILABLE)                return ST_AMB_UNAVAILABLE;
    if (a.driverId == 0)                          return ST_NO_DRIVER;

    a.status = AMB_BUSY;
    r.ambulanceId = a.ambulanceId;
    r.status = REQ_DISPATCHED;

    if (fleet_update_ambulance(&a) != 0) return ST_IO_ERROR;
    if (request_update(&r) != 0) {
        a.status = AMB_AVAILABLE;               /* roll back */
        fleet_update_ambulance(&a);
        return ST_IO_ERROR;
    }
    return ST_OK;
}

int status_advance(int requestId, int restrictAmbulanceId)
{
    Request r;

    if (!request_find(requestId, &r)) return ST_NOT_FOUND;
    if (restrictAmbulanceId != 0 && r.ambulanceId != restrictAmbulanceId) return ST_NOT_OWNER;
    if (r.status < REQ_DISPATCHED || r.status > REQ_TRANSPORTING) return ST_BAD_STATE;

    r.status++;
    if (request_update(&r) != 0) return ST_IO_ERROR;
    if (r.status == REQ_COMPLETED && release_ambulance(r.ambulanceId) != 0) return ST_IO_ERROR;
    return ST_OK;
}

int status_cancel(int requestId, int isAdmin, int callerId)
{
    Request r;
    int hadAmbulance;

    if (!request_find(requestId, &r)) return ST_NOT_FOUND;

    if (!isAdmin) {
        if (r.callerId != callerId) return ST_NOT_OWNER;
        if (r.status == REQ_EN_ROUTE) return ST_ADMIN_ONLY;
        if (r.status != REQ_PENDING && r.status != REQ_DISPATCHED) return ST_BAD_STATE;
    } else {
        if (r.status != REQ_PENDING && r.status != REQ_DISPATCHED && r.status != REQ_EN_ROUTE) {
            return ST_BAD_STATE;
        }
    }

    hadAmbulance = (r.status == REQ_DISPATCHED || r.status == REQ_EN_ROUTE);
    r.status = REQ_CANCELLED;
    if (request_update(&r) != 0) return ST_IO_ERROR;
    if (hadAmbulance && release_ambulance(r.ambulanceId) != 0) return ST_IO_ERROR;
    return ST_OK;
}
