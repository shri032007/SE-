/*
 * request_mgmt.c - Request Management module.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "auth.h"
#include "config.h"
#include "fleet.h"
#include "request_mgmt.h"
#include "storage.h"
#include "utils.h"

static const EmergencyType EMERGENCY_TYPES[] = {
    { "Cardiac arrest",     PRIORITY_CRITICAL },
    { "Severe accident",    PRIORITY_CRITICAL },
    { "Breathing trouble",  PRIORITY_CRITICAL },
    { "Fracture",           PRIORITY_SERIOUS  },
    { "High fever",         PRIORITY_SERIOUS  },
    { "Pregnancy case",     PRIORITY_SERIOUS  },
    { "Minor injury",       PRIORITY_NORMAL   },
    { "Patient transfer",   PRIORITY_NORMAL   },
    { "Other non-urgent",   PRIORITY_NORMAL   }
};

const EmergencyType *request_emergency_types(int *count)
{
    *count = (int)(sizeof EMERGENCY_TYPES / sizeof EMERGENCY_TYPES[0]);
    return EMERGENCY_TYPES;
}

const char *priority_name(int priority)
{
    switch (priority) {
        case PRIORITY_CRITICAL: return "Critical";
        case PRIORITY_SERIOUS:  return "Serious";
        case PRIORITY_NORMAL:   return "Normal";
        default:                return "Unknown";
    }
}

const char *request_status_name(int status)
{
    switch (status) {
        case REQ_PENDING:      return "Pending";
        case REQ_DISPATCHED:   return "Dispatched";
        case REQ_EN_ROUTE:     return "En Route";
        case REQ_TRANSPORTING: return "Transporting";
        case REQ_COMPLETED:    return "Completed";
        case REQ_CANCELLED:    return "Cancelled";
        default:               return "Unknown";
    }
}

int request_is_active(int status)
{
    return status >= REQ_PENDING && status <= REQ_TRANSPORTING;
}

/* ---------------- create / find / update ---------------- */

int request_create(int callerId, const char *patient, const char *contact,
                   const char *location, const char *emergencyType,
                   int priority, Request *out)
{
    Request *arr = NULL, r;
    size_t n = 0, i;
    int maxId = FIRST_REQUEST_ID - 1;

    if (!auth_find_user(callerId, NULL)) return RM_ERR_NO_CALLER;
    if (load_requests(&arr, &n) != 0)    return RM_ERR_IO;

    for (i = 0; i < n; i++) {
        if (arr[i].requestId > maxId) maxId = arr[i].requestId;
        /* block a duplicate active request for the same patient */
        if (arr[i].callerId == callerId && request_is_active(arr[i].status) &&
            util_iequals(arr[i].patientName, patient) &&
            strcmp(arr[i].contact, contact) == 0) {
            if (out != NULL) *out = arr[i];
            free(arr);
            return RM_ERR_DUPLICATE;
        }
    }
    free(arr);

    memset(&r, 0, sizeof r);
    r.requestId = maxId + 1;
    r.callerId  = callerId;
    util_copy(r.patientName,   sizeof r.patientName,   patient);
    util_copy(r.contact,       sizeof r.contact,       contact);
    util_copy(r.location,      sizeof r.location,      location);
    util_copy(r.emergencyType, sizeof r.emergencyType, emergencyType);
    r.priority    = priority;
    r.status      = REQ_PENDING;
    r.ambulanceId = 0;
    time_now_str(r.requestTime, sizeof r.requestTime);

    if (append_request(&r) != 0) return RM_ERR_IO;
    if (out != NULL) *out = r;
    return RM_OK;
}

int request_find(int requestId, Request *out)
{
    Request *arr = NULL;
    size_t n = 0, i;
    int found = 0;
    if (load_requests(&arr, &n) != 0) return 0;
    for (i = 0; i < n; i++) {
        if (arr[i].requestId == requestId) {
            if (out != NULL) *out = arr[i];
            found = 1;
            break;
        }
    }
    free(arr);
    return found;
}

int request_update(const Request *r)
{
    Request *arr = NULL;
    size_t n = 0, i;
    int rc = -1;
    if (load_requests(&arr, &n) != 0) return -1;
    for (i = 0; i < n; i++) {
        if (arr[i].requestId == r->requestId) {
            arr[i] = *r;
            rc = save_requests(arr, n);
            break;
        }
    }
    free(arr);
    return rc;
}

int request_set_priority(int requestId, int priority)
{
    Request r;
    if (!request_find(requestId, &r))   return RM_ERR_NOT_FOUND;
    if (!request_is_active(r.status))   return RM_ERR_CLOSED;
    r.priority = priority;
    return request_update(&r) == 0 ? RM_OK : RM_ERR_IO;
}

/* ---------------- sorting / waiting time ---------------- */

static int cmp_priority_time(const void *a, const void *b)
{
    const Request *x = (const Request *)a;
    const Request *y = (const Request *)b;
    int c;
    if (x->priority != y->priority) return x->priority - y->priority;
    c = strcmp(x->requestTime, y->requestTime);
    if (c != 0) return c;
    return x->requestId - y->requestId;
}

void request_sort_by_priority(Request *arr, size_t n)
{
    if (n > 1) qsort(arr, n, sizeof *arr, cmp_priority_time);
}

int request_wait_limit_minutes(int priority)
{
    switch (priority) {
        case PRIORITY_CRITICAL: return ESCALATE_CRITICAL_MIN;
        case PRIORITY_SERIOUS:  return ESCALATE_SERIOUS_MIN;
        default:                return ESCALATE_NORMAL_MIN;
    }
}

double request_wait_minutes(const Request *r)
{
    return minutes_since(r->requestTime);
}

int request_get_stats(RequestStats *s)
{
    Request *arr = NULL;
    size_t n = 0, i;

    memset(s, 0, sizeof *s);
    if (load_requests(&arr, &n) != 0) return -1;
    s->total = (int)n;
    for (i = 0; i < n; i++) {
        switch (arr[i].status) {
            case REQ_PENDING:
                s->pending++;
                if (arr[i].priority == PRIORITY_CRITICAL) s->pendingCritical++;
                if (request_wait_minutes(&arr[i]) >= request_wait_limit_minutes(arr[i].priority)) {
                    s->delayed++;
                }
                break;
            case REQ_DISPATCHED:   s->dispatched++;   break;
            case REQ_EN_ROUTE:     s->enRoute++;      break;
            case REQ_TRANSPORTING: s->transporting++; break;
            case REQ_COMPLETED:    s->completed++;    break;
            case REQ_CANCELLED:    s->cancelled++;    break;
            default: break;
        }
    }
    free(arr);
    return 0;
}

/* ---------------- printing ---------------- */

void request_print_table(const Request *arr, size_t n)
{
    size_t i;
    if (n == 0) { puts("  (no requests to show)"); return; }

    printf("%-5s %-14s %-17s %-9s %-13s %-4s %-19s %-16s\n",
           "ID", "Patient", "Emergency", "Priority", "Status", "Amb", "Requested at", "Location");
    puts("---------------------------------------------------------------------------------------------------------");
    for (i = 0; i < n; i++) {
        const Request *r = &arr[i];
        printf("%-5d %-14.14s %-17.17s %-9s %-13s ",
               r->requestId, r->patientName, r->emergencyType,
               priority_name(r->priority), request_status_name(r->status));
        if (r->ambulanceId != 0) printf("%-4d ", r->ambulanceId);
        else                     printf("%-4s ", "-");
        printf("%-19s %-16.16s\n", r->requestTime, r->location);
    }
    printf("\n  Total: %d request(s)\n", (int)n);
}

void request_print_details(const Request *r)
{
    Ambulance a;
    Driver d;

    ui_line();
    printf("  Request ID    : %d\n", r->requestId);
    printf("  Patient       : %s\n", r->patientName);
    printf("  Contact       : %s\n", r->contact);
    printf("  Location      : %s\n", r->location);
    printf("  Emergency     : %s\n", r->emergencyType);
    printf("  Priority      : %s\n", priority_name(r->priority));
    printf("  Status        : %s\n", request_status_name(r->status));
    printf("  Requested at  : %s\n", r->requestTime);
    if (r->ambulanceId != 0 && fleet_find_ambulance(r->ambulanceId, &a)) {
        printf("  Ambulance     : %s (%s, %s)\n", a.vehicleNo, a.type, a.area);
        if (a.driverId != 0 && fleet_find_driver(a.driverId, &d)) {
            printf("  Driver        : %s  (%s)\n", d.name, d.contact);
        }
    } else {
        printf("  Ambulance     : not allocated yet\n");
    }
    ui_line();
}
