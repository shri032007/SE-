/*
 * utils.c - Console UI helpers, safe input, validation, time and string tools.
 */
#include <ctype.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#ifdef _WIN32
  #include <conio.h>
  #include <direct.h>
  #include <io.h>
  #define AMS_ISATTY()  _isatty(_fileno(stdin))
  #define AMS_CLEAR()   system("cls")
#else
  #include <sys/stat.h>
  #include <sys/types.h>
  #include <termios.h>
  #include <unistd.h>
  #define AMS_ISATTY()  isatty(STDIN_FILENO)
  #define AMS_CLEAR()   system("clear")
#endif

#include "config.h"
#include "utils.h"

/* ====================================================================== */
/*  Console UI                                                            */
/* ====================================================================== */

void ui_clear(void)
{
    if (AMS_ISATTY()) {
        (void)AMS_CLEAR();
    }
}

void ui_line(void)
{
    puts("------------------------------------------------------------");
}

void ui_header(const char *title)
{
    ui_clear();
    puts("============================================================");
    printf("  %s  v%s\n", APP_NAME, APP_VERSION);
    puts("============================================================");
    if (title != NULL && title[0] != '\0') {
        printf("  %s\n", title);
        ui_line();
    }
}

void ui_pause(void)
{
    char tmp[8];
    input_line("\nPress Enter to continue...", tmp, sizeof tmp);
}

/* ====================================================================== */
/*  Safe input                                                            */
/* ====================================================================== */

/* Reads one line, removes the newline, trims spaces. Exits if input closed. */
void input_line(const char *prompt, char *buf, size_t size)
{
    if (prompt != NULL) {
        printf("%s", prompt);
        fflush(stdout);
    }
    if (fgets(buf, (int)size, stdin) == NULL) {
        printf("\n[Input closed - exiting]\n");
        exit(EXIT_SUCCESS);
    }
    size_t len = strlen(buf);
    if (len > 0 && buf[len - 1] == '\n') {
        buf[len - 1] = '\0';
    } else {
        /* line was longer than the buffer: throw away the rest of it */
        int c;
        while ((c = getchar()) != '\n' && c != EOF) { /* discard */ }
    }
    str_trim(buf);
}

/* Reads a non-empty text that fits in 'size' bytes (including '\0'). */
void input_required(const char *prompt, char *buf, size_t size)
{
    char tmp[256];
    for (;;) {
        input_line(prompt, tmp, sizeof tmp);
        if (tmp[0] == '\0') {
            puts("  This field cannot be empty.");
            continue;
        }
        if (strlen(tmp) >= size) {
            printf("  Too long (maximum %d characters).\n", (int)(size - 1));
            continue;
        }
        util_copy(buf, size, tmp);
        return;
    }
}

int input_int(const char *prompt, int min, int max)
{
    char buf[32];
    for (;;) {
        input_line(prompt, buf, sizeof buf);
        char *end = NULL;
        errno = 0;
        long v = strtol(buf, &end, 10);
        if (buf[0] == '\0' || *end != '\0' || errno == ERANGE || v < min || v > max) {
            printf("  Invalid input. Enter a number from %d to %d.\n", min, max);
            continue;
        }
        return (int)v;
    }
}

int input_yes_no(const char *prompt)
{
    char buf[8];
    for (;;) {
        input_line(prompt, buf, sizeof buf);
        if (util_iequals(buf, "y") || util_iequals(buf, "yes")) return 1;
        if (util_iequals(buf, "n") || util_iequals(buf, "no"))  return 0;
        puts("  Please answer y or n.");
    }
}

void input_name(const char *prompt, char *buf, size_t size)
{
    char tmp[NAME_LEN];
    for (;;) {
        input_required(prompt, tmp, sizeof tmp);
        if (!validate_name(tmp)) {
            puts("  Name may contain only letters, spaces, '.', '-' (min 2 letters).");
            continue;
        }
        util_copy(buf, size, tmp);
        return;
    }
}

void input_contact(const char *prompt, char *buf, size_t size)
{
    char tmp[CONTACT_LEN];
    for (;;) {
        input_required(prompt, tmp, sizeof tmp);
        if (!validate_contact(tmp)) {
            puts("  Contact number must be exactly 10 digits.");
            continue;
        }
        util_copy(buf, size, tmp);
        return;
    }
}

/*
 * Reads a password WITHOUT echoing it; shows '*' for each character.
 * Supports Backspace. Works on Windows (conio) and Linux/macOS (termios).
 */
void input_password(const char *prompt, char *buf, size_t size)
{
    size_t len = 0;
    int limit = (int)size - 1;
    if (limit > PASSWORD_INPUT_MAX) limit = PASSWORD_INPUT_MAX;

    if (prompt != NULL) {
        printf("%s", prompt);
        fflush(stdout);
    }

    if (!AMS_ISATTY()) {                 /* input is piped / redirected */
        input_line(NULL, buf, size);
        return;
    }

#ifdef _WIN32
    for (;;) {
        int ch = _getch();
        if (ch == '\r' || ch == '\n') break;
        if (ch == 0 || ch == 0xE0) { (void)_getch(); continue; } /* arrow/function keys */
        if (ch == 3) { puts(""); exit(EXIT_SUCCESS); }           /* Ctrl+C */
        if (ch == '\b') {
            if (len > 0) { len--; fputs("\b \b", stdout); fflush(stdout); }
            continue;
        }
        if (ch >= 32 && ch < 127 && (int)len < limit) {
            buf[len++] = (char)ch;
            putchar('*');
            fflush(stdout);
        }
    }
#else
    struct termios oldt, newt;
    if (tcgetattr(STDIN_FILENO, &oldt) != 0) {
        input_line(NULL, buf, size);
        return;
    }
    newt = oldt;
    newt.c_lflag &= (tcflag_t)~(ECHO | ICANON);
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);
    for (;;) {
        int ch = getchar();
        if (ch == EOF || ch == '\n' || ch == '\r') break;
        if (ch == 127 || ch == '\b') {
            if (len > 0) { len--; fputs("\b \b", stdout); fflush(stdout); }
            continue;
        }
        if (ch >= 32 && ch < 127 && (int)len < limit) {
            buf[len++] = (char)ch;
            putchar('*');
            fflush(stdout);
        }
    }
    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
#endif
    buf[len] = '\0';
    putchar('\n');
}

/* ====================================================================== */
/*  Validation                                                            */
/* ====================================================================== */

int validate_name(const char *s)
{
    int letters = 0;
    if (s == NULL) return 0;
    for (; *s; s++) {
        unsigned char c = (unsigned char)*s;
        if (isalpha(c)) letters++;
        else if (c != ' ' && c != '.' && c != '-') return 0;
    }
    return letters >= 2;
}

int validate_contact(const char *s)
{
    size_t i, len;
    if (s == NULL) return 0;
    len = strlen(s);
    if (len != 10) return 0;
    for (i = 0; i < len; i++) {
        if (!isdigit((unsigned char)s[i])) return 0;
    }
    return 1;
}

/* Vehicle number: 6 to 14 letters/digits, e.g. KA25AB1234 */
int validate_vehicle_no(const char *s)
{
    size_t i, len;
    if (s == NULL) return 0;
    len = strlen(s);
    if (len < 6 || len >= VEHICLE_LEN) return 0;
    for (i = 0; i < len; i++) {
        if (!isalnum((unsigned char)s[i])) return 0;
    }
    return 1;
}

/* ====================================================================== */
/*  Strings                                                               */
/* ====================================================================== */

void str_trim(char *s)
{
    size_t len = strlen(s), start = 0;
    while (len > 0 && isspace((unsigned char)s[len - 1])) len--;
    s[len] = '\0';
    while (s[start] != '\0' && isspace((unsigned char)s[start])) start++;
    if (start > 0) memmove(s, s + start, strlen(s + start) + 1);
}

/* Safe bounded copy: always null-terminates, never overflows. */
void util_copy(char *dst, size_t size, const char *src)
{
    size_t n;
    if (size == 0) return;
    n = strlen(src);
    if (n >= size) n = size - 1;
    memcpy(dst, src, n);
    dst[n] = '\0';
}

void util_to_upper(char *s)
{
    for (; *s; s++) *s = (char)toupper((unsigned char)*s);
}

int util_iequals(const char *a, const char *b)
{
    while (*a && *b) {
        if (tolower((unsigned char)*a) != tolower((unsigned char)*b)) return 0;
        a++; b++;
    }
    return *a == *b;
}

int util_icontains(const char *hay, const char *needle)
{
    size_t nlen = strlen(needle), i, j;
    size_t hlen = strlen(hay);
    if (nlen == 0) return 1;
    if (nlen > hlen) return 0;
    for (i = 0; i + nlen <= hlen; i++) {
        for (j = 0; j < nlen; j++) {
            if (tolower((unsigned char)hay[i + j]) != tolower((unsigned char)needle[j])) break;
        }
        if (j == nlen) return 1;
    }
    return 0;
}

/* Clears sensitive data (passwords) from memory. */
void util_wipe(void *p, size_t n)
{
    volatile unsigned char *v = (volatile unsigned char *)p;
    while (n--) *v++ = 0;
}

/* ====================================================================== */
/*  Time                                                                  */
/* ====================================================================== */

void time_now_str(char *buf, size_t size)
{
    time_t now = time(NULL);
    struct tm *lt = localtime(&now);
    if (lt == NULL || strftime(buf, size, "%Y-%m-%d %H:%M:%S", lt) == 0) {
        util_copy(buf, size, "0000-00-00 00:00:00");
    }
}

/* Minutes elapsed since a "YYYY-MM-DD HH:MM:SS" timestamp. */
double minutes_since(const char *timestamp)
{
    int y, mo, d, h, mi, s;
    struct tm t;
    time_t then;
    if (sscanf(timestamp, "%d-%d-%d %d:%d:%d", &y, &mo, &d, &h, &mi, &s) != 6) {
        return 0.0;
    }
    memset(&t, 0, sizeof t);
    t.tm_year = y - 1900;
    t.tm_mon  = mo - 1;
    t.tm_mday = d;
    t.tm_hour = h;
    t.tm_min  = mi;
    t.tm_sec  = s;
    t.tm_isdst = -1;
    then = mktime(&t);
    if (then == (time_t)-1) return 0.0;
    return difftime(time(NULL), then) / 60.0;
}

/* ====================================================================== */
/*  File system                                                           */
/* ====================================================================== */

/* Creates a directory if it does not exist. Returns 0 on success. */
int fs_ensure_dir(const char *path)
{
#ifdef _WIN32
    if (_mkdir(path) == 0 || errno == EEXIST) return 0;
#else
    if (mkdir(path, 0755) == 0 || errno == EEXIST) return 0;
#endif
    return -1;
}
