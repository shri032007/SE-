/*
 * main.c - Ambulance Management System: entry point and main menu.
 *
 * Modules (see architecture diagram):
 *   Caller Module, Admin/Dispatch Module, Driver Module,
 *   Request Management, Status Tracking, Search & Filtering,
 *   Account Management (auth), Fleet, File Handling (storage).
 */
#include <stdio.h>
#include <stdlib.h>

#include "admin_module.h"
#include "auth.h"
#include "caller_module.h"
#include "driver_module.h"
#include "models.h"
#include "storage.h"
#include "utils.h"

int main(void)
{
    if (storage_init() != 0) {
        fprintf(stderr, "Fatal error: cannot create or open the data files in the '%s' folder.\n",
                DATA_DIR);
        return EXIT_FAILURE;
    }

    for (;;) {
        User user;
        int choice;

        ui_header("MAIN MENU");
        puts("  1. Caller login");
        puts("  2. Admin (Dispatcher) login");
        puts("  3. Driver / Paramedic login");
        puts("  4. New caller registration");
        puts("  0. Exit");
        choice = input_int("\nEnter choice: ", 0, 4);

        switch (choice) {
            case 1:
                if (auth_login(ROLE_CALLER, &user)) { ui_pause(); caller_menu(&user); }
                else ui_pause();
                break;
            case 2:
                if (auth_login(ROLE_ADMIN, &user))  { ui_pause(); admin_menu(&user); }
                else ui_pause();
                break;
            case 3:
                if (auth_login(ROLE_DRIVER, &user)) { ui_pause(); driver_menu(&user); }
                else ui_pause();
                break;
            case 4:
                auth_register_caller();
                ui_pause();
                break;
            case 0:
                puts("\nThank you for using the Ambulance Management System. Stay safe!");
                return EXIT_SUCCESS;
            default:
                break;
        }
    }
}
