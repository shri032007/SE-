/*
 * auth.c - Account Management module.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "auth.h"
#include "config.h"
#include "storage.h"
#include "utils.h"

static time_t s_lockedUntil = 0;     /* login lock-out (for this program run) */

const char *auth_role_name(int role)
{
    switch (role) {
        case ROLE_CALLER: return "Caller";
        case ROLE_ADMIN:  return "Admin";
        case ROLE_DRIVER: return "Driver";
        default:          return "Unknown";
    }
}

/*
 * FNV-1a 64-bit hash, salted with the user ID, written as 16 hex characters
 * so it fits inside password[20]. This keeps plain passwords out of the data
 * files. (For a real deployment use bcrypt/argon2 instead.)
 */
void auth_hash_password(int userId, const char *plain, char out[PASSWORD_LEN])
{
    static const char hex[] = "0123456789abcdef";
    unsigned long long h = 14695981039346656037ULL;
    char salt[32];
    const char *p;
    int i;

    snprintf(salt, sizeof salt, "AMS$%d$", userId);
    for (p = salt; *p; p++)  { h ^= (unsigned char)*p; h *= 1099511628211ULL; }
    for (p = plain; *p; p++) { h ^= (unsigned char)*p; h *= 1099511628211ULL; }

    memset(out, 0, PASSWORD_LEN);
    for (i = 0; i < 16; i++) {
        out[i] = hex[(h >> (60 - 4 * i)) & 0xF];
    }
}

int auth_find_user(int userId, User *out)
{
    User *users = NULL;
    size_t n = 0, i;
    int found = 0;

    if (load_users(&users, &n) != 0) return 0;
    for (i = 0; i < n; i++) {
        if (users[i].userId == userId) {
            if (out != NULL) *out = users[i];
            found = 1;
            break;
        }
    }
    free(users);
    return found;
}

static int next_user_id(void)
{
    User *users = NULL;
    size_t n = 0, i;
    int maxId = FIRST_USER_ID - 1;

    if (load_users(&users, &n) != 0) return -1;
    for (i = 0; i < n; i++) {
        if (users[i].userId > maxId) maxId = users[i].userId;
    }
    free(users);
    return maxId + 1;
}

int auth_create_user(const char *name, const char *plain, int role)
{
    User u;
    int id = next_user_id();
    if (id < 0) return -1;

    memset(&u, 0, sizeof u);
    u.userId = id;
    util_copy(u.name, sizeof u.name, name);
    auth_hash_password(id, plain, u.password);
    u.role = role;
    return append_user(&u) == 0 ? id : -1;
}

/* Asks for a new password twice (hidden). Result is plain text in 'out'. */
static void read_new_password(char *out, size_t size)
{
    char confirm[PASSWORD_INPUT_MAX + 1];
    for (;;) {
        input_password("  New password (min 6 characters): ", out, size);
        if (strlen(out) < MIN_PASSWORD_LEN) {
            printf("  Password must be at least %d characters.\n", MIN_PASSWORD_LEN);
            continue;
        }
        input_password("  Confirm password               : ", confirm, sizeof confirm);
        if (strcmp(out, confirm) != 0) {
            puts("  Passwords do not match. Try again.");
            continue;
        }
        util_wipe(confirm, sizeof confirm);
        return;
    }
}

int auth_login(int role, User *out)
{
    enum { FAIL_NONE, FAIL_USER, FAIL_PASSWORD };
    int attempt;
    time_t now = time(NULL);

    if (now < s_lockedUntil) {
        printf("\nToo many failed attempts. Login is locked. Try again in %d second(s).\n",
               (int)(s_lockedUntil - now));
        return 0;
    }

    printf("\n%s Login  (Enter User ID 0 to go back)\n", auth_role_name(role));
    ui_line();

    for (attempt = 1; attempt <= MAX_LOGIN_ATTEMPTS; attempt++) {
        char pw[PASSWORD_INPUT_MAX + 1];
        char hash[PASSWORD_LEN];
        User *users = NULL;
        size_t n = 0, i;
        int id, fail = FAIL_USER;
        User match;

        memset(&match, 0, sizeof match);
        id = input_int("User ID  : ", 0, 999999);
        if (id == 0) return 0;
        input_password("Password : ", pw, sizeof pw);

        if (load_users(&users, &n) != 0) {
            puts("Error: unable to read user records.");
            util_wipe(pw, sizeof pw);
            return 0;
        }
        for (i = 0; i < n; i++) {
            if (users[i].userId == id && users[i].role == role) {
                match = users[i];
                fail = FAIL_PASSWORD;
                break;
            }
        }
        free(users);

        if (fail == FAIL_PASSWORD) {
            auth_hash_password(id, pw, hash);
            if (strcmp(hash, match.password) == 0) fail = FAIL_NONE;
        }
        util_wipe(pw, sizeof pw);

        if (fail == FAIL_NONE) {
            *out = match;
            printf("\nLogin successful. Welcome, %s!\n", match.name);
            return 1;
        }

#if REVEAL_LOGIN_FAILURE_REASON
        if (fail == FAIL_USER) {
            printf("\n  [X] Wrong User ID - no %s account with ID %d.\n",
                   auth_role_name(role), id);
        } else {
            puts("\n  [X] Wrong Password for this User ID.");
        }
#else
        puts("\n  [X] Invalid User ID or Password.");
#endif
        if (attempt < MAX_LOGIN_ATTEMPTS) {
            printf("  Attempts remaining: %d\n\n", MAX_LOGIN_ATTEMPTS - attempt);
        }
    }

    s_lockedUntil = time(NULL) + LOCKOUT_SECONDS;
    printf("\nMaximum attempts (%d) reached. Login locked for %d seconds.\n",
           MAX_LOGIN_ATTEMPTS, LOCKOUT_SECONDS);
    return 0;
}

int auth_register_caller(void)
{
    char name[NAME_LEN];
    char pw[PASSWORD_INPUT_MAX + 1];
    int id;

    ui_header("NEW CALLER REGISTRATION");
    input_name("  Full name: ", name, sizeof name);
    read_new_password(pw, sizeof pw);

    id = auth_create_user(name, pw, ROLE_CALLER);
    util_wipe(pw, sizeof pw);
    if (id < 0) {
        puts("\nError: could not save the account.");
        return 0;
    }
    printf("\nRegistration successful!\n");
    printf("  Your User ID is: %d   (remember it - you need it to log in)\n", id);
    return 1;
}

void auth_change_password(const User *user)
{
    User *users = NULL;
    size_t n = 0, i;
    int idx = -1, tries;

    ui_header("CHANGE PASSWORD");
    if (load_users(&users, &n) != 0) {
        puts("Error: unable to read user records.");
        return;
    }
    for (i = 0; i < n; i++) {
        if (users[i].userId == user->userId) { idx = (int)i; break; }
    }
    if (idx < 0) {
        puts("Error: account not found.");
        free(users);
        return;
    }

    for (tries = 1; tries <= MAX_LOGIN_ATTEMPTS; tries++) {
        char cur[PASSWORD_INPUT_MAX + 1];
        char hash[PASSWORD_LEN];
        input_password("  Current password: ", cur, sizeof cur);
        auth_hash_password(user->userId, cur, hash);
        util_wipe(cur, sizeof cur);
        if (strcmp(hash, users[idx].password) == 0) {
            char np[PASSWORD_INPUT_MAX + 1];
            read_new_password(np, sizeof np);
            auth_hash_password(user->userId, np, users[idx].password);
            util_wipe(np, sizeof np);
            if (save_users(users, n) == 0) puts("\nPassword changed successfully.");
            else                           puts("\nError: could not save the new password.");
            free(users);
            return;
        }
        printf("  [X] Wrong password. Attempts remaining: %d\n", MAX_LOGIN_ATTEMPTS - tries);
    }
    puts("\nToo many wrong attempts. Password was not changed.");
    free(users);
}
