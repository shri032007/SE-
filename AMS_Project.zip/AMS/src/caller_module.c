/*
 * caller_module.c - Caller Module.
 */
#include <stdio.h>
#include <stdlib.h>

#include "auth.h"
#include "caller_module.h"
#include "request_mgmt.h"
#include "search_filter.h"
#include "status_tracking.h"
#include "storage.h"
#include "utils.h"

static void submit_request(const User *user)
{
    char patient[NAME_LEN], contact[CONTACT_LEN], location[LOCATION_LEN];
    const EmergencyType *types;
    int count, i, choice, rc;
    Request r;

    ui_header("SUBMIT EMERGENCY REQUEST");
    input_name("  Patient name      : ", patient, sizeof patient);
    input_contact("  Contact (10 digits): ", contact, sizeof contact);
    input_required("  Location / address: ", location, sizeof location);

    types = request_emergency_types(&count);
    puts("\n  Type of emergency:");
    for (i = 0; i < count; i++) {
        printf("   %d. %-18s (%s)\n", i + 1, types[i].name, priority_name(types[i].priority));
    }
    choice = input_int("\n  Select type: ", 1, count);

    rc = request_create(user->userId, patient, contact, location,
                        types[choice - 1].name, types[choice - 1].priority, &r);
    puts("");
    if (rc == RM_OK) {
        puts("Request registered successfully!");
        printf("  Request ID : %d\n", r.requestId);
        printf("  Priority   : %s\n", priority_name(r.priority));
        printf("  Status     : %s\n", request_status_name(r.status));
        printf("  Time       : %s\n", r.requestTime);
        puts("\n  Keep your Request ID to track the status.");
    } else if (rc == RM_ERR_DUPLICATE) {
        printf("An active request for this patient already exists (Request ID %d, status %s).\n",
               r.requestId, request_status_name(r.status));
    } else if (rc == RM_ERR_NO_CALLER) {
        puts("Error: your account could not be verified.");
    } else {
        puts("Error: could not save the request.");
    }
}

static void track_requests(const User *user)
{
    Request *arr = NULL;
    size_t n = 0, i, k = 0;
    int id;

    ui_header("TRACK MY REQUESTS");
    if (load_requests(&arr, &n) != 0) {
        puts("Error: unable to read requests.");
        return;
    }
    for (i = 0; i < n; i++) {
        if (arr[i].callerId == user->userId) arr[k++] = arr[i];
    }
    request_print_table(arr, k);

    if (k > 0) {
        id = input_int("\nEnter Request ID for full details (0 to go back): ", 0, 999999);
        if (id != 0) {
            int found = 0;
            for (i = 0; i < k; i++) {
                if (arr[i].requestId == id) {
                    request_print_details(&arr[i]);
                    found = 1;
                    break;
                }
            }
            if (!found) puts("  That Request ID is not one of your requests.");
        }
    }
    free(arr);
}

static void cancel_request(const User *user)
{
    int id, rc;
    Request r;

    ui_header("CANCEL A REQUEST");
    id = input_int("Enter Request ID to cancel (0 to go back): ", 0, 999999);
    if (id == 0) return;
    if (!request_find(id, &r) || r.callerId != user->userId) {
        puts("\nRequest not found among your requests.");
        return;
    }
    request_print_details(&r);
    if (!input_yes_no("Cancel this request? (y/n): ")) {
        puts("Cancellation aborted.");
        return;
    }
    rc = status_cancel(id, 0, user->userId);
    if (rc == ST_OK) puts("\nRequest cancelled.");
    else             printf("\nCannot cancel: %s\n", status_message(rc));
}

void caller_menu(const User *user)
{
    for (;;) {
        int choice;
        ui_header("CALLER MENU");
        printf("  Logged in as: %s (ID %d)\n\n", user->name, user->userId);
        puts("  1. Submit emergency request");
        puts("  2. Track my requests");
        puts("  3. Cancel a request");
        puts("  4. Search / filter my requests");
        puts("  5. Change password");
        puts("  0. Logout");
        choice = input_int("\nEnter choice: ", 0, 5);

        switch (choice) {
            case 1: submit_request(user);            ui_pause(); break;
            case 2: track_requests(user);            ui_pause(); break;
            case 3: cancel_request(user);            ui_pause(); break;
            case 4: search_requests_menu(user->userId);          break;
            case 5: auth_change_password(user);      ui_pause(); break;
            case 0: puts("\nLogged out."); return;
            default: break;
        }
    }
}
