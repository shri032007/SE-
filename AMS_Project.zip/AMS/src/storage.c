/*
 * storage.c - File Handling Layer.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "auth.h"
#include "config.h"
#include "storage.h"
#include "utils.h"

/* ---------------- generic fixed-size record helpers ---------------- */

static int store_load(const char *path, size_t rec, void **out, size_t *count)
{
    FILE *fp;
    long size;
    size_t n;
    void *buf;

    *out = NULL;
    *count = 0;

    fp = fopen(path, "rb");
    if (fp == NULL) return 0;                 /* missing file == no records */

    if (fseek(fp, 0, SEEK_END) != 0) { fclose(fp); return -1; }
    size = ftell(fp);
    if (size < 0) { fclose(fp); return -1; }
    rewind(fp);

    n = (size_t)size / rec;
    if (n == 0) { fclose(fp); return 0; }

    buf = malloc(n * rec);
    if (buf == NULL) { fclose(fp); return -1; }

    if (fread(buf, rec, n, fp) != n) {
        free(buf);
        fclose(fp);
        return -1;
    }
    fclose(fp);
    *out = buf;
    *count = n;
    return 0;
}

/* Writes to a temporary file first, then swaps it in (protects old data). */
static int store_save(const char *path, size_t rec, const void *data, size_t n)
{
    char tmp[128];
    FILE *fp;

    snprintf(tmp, sizeof tmp, "%s.tmp", path);
    fp = fopen(tmp, "wb");
    if (fp == NULL) return -1;
    if (n > 0 && fwrite(data, rec, n, fp) != n) {
        fclose(fp);
        remove(tmp);
        return -1;
    }
    if (fclose(fp) != 0) {
        remove(tmp);
        return -1;
    }
    remove(path);
    if (rename(tmp, path) != 0) return -1;
    return 0;
}

static int store_append(const char *path, size_t rec, const void *data)
{
    FILE *fp = fopen(path, "ab");
    if (fp == NULL) return -1;
    if (fwrite(data, rec, 1, fp) != 1) {
        fclose(fp);
        return -1;
    }
    return fclose(fp) == 0 ? 0 : -1;
}

/* Generates load_/save_/append_ functions for one record type. */
#define DEFINE_STORE(Type, name, one, path)                                       \
    int load_##name(Type **out, size_t *count)                                 \
    {                                                                          \
        void *p = NULL;                                                        \
        int rc = store_load(path, sizeof(Type), &p, count);                    \
        *out = (Type *)p;                                                      \
        return rc;                                                             \
    }                                                                          \
    int save_##name(const Type *arr, size_t count)                             \
    {                                                                          \
        return store_save(path, sizeof(Type), arr, count);                     \
    }                                                                          \
    int append_##one(const Type *rec)                                          \
    {                                                                          \
        return store_append(path, sizeof(Type), rec);                          \
    }

DEFINE_STORE(User,      users,      user,      USERS_FILE)
DEFINE_STORE(Request,   requests,   request,   REQUEST_FILE)
DEFINE_STORE(Ambulance, ambulances, ambulance, AMBULANCE_FILE)
DEFINE_STORE(Driver,    drivers,    driver,    DRIVER_FILE)

/* ---------------- first-run set-up ---------------- */

static int touch_file(const char *path)
{
    FILE *fp = fopen(path, "ab");
    if (fp == NULL) return -1;
    fclose(fp);
    return 0;
}

static void make_user(User *u, int id, const char *name, const char *plain, int role)
{
    memset(u, 0, sizeof *u);
    u->userId = id;
    util_copy(u->name, sizeof u->name, name);
    auth_hash_password(id, plain, u->password);
    u->role = role;
}

/*
 * Default data so the system can be used immediately:
 *   Admin  : ID 1   password admin123
 *   Drivers: ID 101-103  password driver123  (each with an ambulance)
 * Change these passwords after the first login (menu option "Change password").
 */
static int seed_defaults(void)
{
    User users[4];
    Driver drivers[3];
    Ambulance amb[3];

    make_user(&users[0], ADMIN_USER_ID, "System Admin",  "admin123",  ROLE_ADMIN);
    make_user(&users[1], 101, "Ramesh Kumar", "driver123", ROLE_DRIVER);
    make_user(&users[2], 102, "Suresh Patil", "driver123", ROLE_DRIVER);
    make_user(&users[3], 103, "Anil Desai",   "driver123", ROLE_DRIVER);

    memset(drivers, 0, sizeof drivers);
    drivers[0].driverId = 101; util_copy(drivers[0].name, NAME_LEN, "Ramesh Kumar");
    util_copy(drivers[0].contact, CONTACT_LEN, "9876543201"); drivers[0].ambulanceId = 1;
    drivers[1].driverId = 102; util_copy(drivers[1].name, NAME_LEN, "Suresh Patil");
    util_copy(drivers[1].contact, CONTACT_LEN, "9876543202"); drivers[1].ambulanceId = 2;
    drivers[2].driverId = 103; util_copy(drivers[2].name, NAME_LEN, "Anil Desai");
    util_copy(drivers[2].contact, CONTACT_LEN, "9876543203"); drivers[2].ambulanceId = 3;

    memset(amb, 0, sizeof amb);
    amb[0].ambulanceId = 1; util_copy(amb[0].vehicleNo, VEHICLE_LEN, "KA25AB1001");
    util_copy(amb[0].type, AMB_TYPE_LEN, "ALS"); util_copy(amb[0].area, AREA_LEN, "Dharwad");
    amb[0].driverId = 101; amb[0].status = AMB_AVAILABLE;
    amb[1].ambulanceId = 2; util_copy(amb[1].vehicleNo, VEHICLE_LEN, "KA25AB1002");
    util_copy(amb[1].type, AMB_TYPE_LEN, "BLS"); util_copy(amb[1].area, AREA_LEN, "Hubballi");
    amb[1].driverId = 102; amb[1].status = AMB_AVAILABLE;
    amb[2].ambulanceId = 3; util_copy(amb[2].vehicleNo, VEHICLE_LEN, "KA25AB1003");
    util_copy(amb[2].type, AMB_TYPE_LEN, "BLS"); util_copy(amb[2].area, AREA_LEN, "Vidyagiri");
    amb[2].driverId = 103; amb[2].status = AMB_AVAILABLE;

    if (save_users(users, 4) != 0)         return -1;
    if (save_drivers(drivers, 3) != 0)     return -1;
    if (save_ambulances(amb, 3) != 0)      return -1;
    return 0;
}

int storage_init(void)
{
    User *users = NULL;
    size_t n = 0;
    int rc = 0;

    if (fs_ensure_dir(DATA_DIR) != 0) return -1;
    if (touch_file(USERS_FILE) != 0 || touch_file(REQUEST_FILE) != 0 ||
        touch_file(AMBULANCE_FILE) != 0 || touch_file(DRIVER_FILE) != 0) {
        return -1;
    }
    if (load_users(&users, &n) != 0) return -1;
    free(users);
    if (n == 0) rc = seed_defaults();
    return rc;
}
